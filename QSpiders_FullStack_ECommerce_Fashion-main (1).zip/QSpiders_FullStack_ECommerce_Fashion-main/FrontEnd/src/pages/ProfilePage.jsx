import React, { useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import { User, Package, MapPin, Heart, LogOut } from 'lucide-react';
import { Link } from 'react-router-dom';

const ProfilePage = () => {
  const { user, logout } = useContext(AuthContext);

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#FAFAFA]">
        <div className="glass p-12 rounded-[2rem] text-center max-w-sm">
          <h3 className="text-2xl font-serif mb-6">Sign in to view profile</h3>
          <Link to="/login" className="bg-deep-black text-white text-[10px] uppercase tracking-widest font-bold py-4 px-10 rounded-full block">Sign In</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#FAFAFA] min-h-screen pt-32 pb-20 px-10">
      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-4 gap-12">
        {/* Sidebar */}
        <div className="lg:col-span-1">
          <div className="glass p-8 rounded-[2rem] sticky top-32">
            <div className="w-20 h-20 bg-soft-gold/10 rounded-full flex items-center justify-center mb-6 text-soft-gold text-2xl font-serif">
              {user.name.charAt(0)}
            </div>
            <h3 className="text-xl font-serif text-deep-black mb-1">{user.name}</h3>
            <p className="text-xs text-gray-400 mb-8 lowercase">{user.email}</p>
            
            <nav className="flex flex-col gap-4">
              <button className="flex items-center gap-4 text-sm font-bold text-deep-black group">
                <Package size={18} className="text-gray-400 group-hover:text-soft-gold" />
                <span className="tracking-wide">Orders</span>
              </button>
              <button className="flex items-center gap-4 text-sm font-bold text-gray-400 hover:text-deep-black group">
                <MapPin size={18} className="group-hover:text-soft-gold" />
                <span className="tracking-wide">Addresses</span>
              </button>
              <button className="flex items-center gap-4 text-sm font-bold text-gray-400 hover:text-deep-black group">
                <Heart size={18} className="group-hover:text-soft-gold" />
                <span className="tracking-wide">Saved Items</span>
              </button>
              <hr className="my-4 border-gray-100" />
              <button onClick={logout} className="flex items-center gap-4 text-sm font-bold text-red-500 group">
                <LogOut size={18} />
                <span className="tracking-wide">Sign Out</span>
              </button>
            </nav>
          </div>
        </div>

        {/* Content */}
        <div className="lg:col-span-3 space-y-10">
          <div className="glass p-12 rounded-[2.5rem]">
            <h2 className="text-3xl font-serif text-deep-black mb-8">Recent Orders</h2>
            <div className="border-t border-gray-100 py-20 text-center">
              <p className="text-gray-400 text-sm tracking-widest uppercase">No orders found</p>
              <Link to="/shop" className="text-soft-gold text-[10px] uppercase tracking-widest font-bold mt-4 inline-block border-b border-soft-gold">Start Shopping</Link>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="glass p-10 rounded-[2.5rem]">
              <h4 className="text-lg font-serif mb-4">Account Details</h4>
              <p className="text-sm text-gray-500 mb-6">Update your personal information and password.</p>
              <button className="text-[10px] uppercase tracking-widest font-black border-b-2 border-black/5 pb-1 hover:border-soft-gold transition-all">Edit Details</button>
            </div>
            <div className="glass p-10 rounded-[2.5rem]">
              <h4 className="text-lg font-serif mb-4">Shipping Address</h4>
              <p className="text-sm text-gray-500 mb-6">Manage your primary delivery address.</p>
              <button className="text-[10px] uppercase tracking-widest font-black border-b-2 border-black/5 pb-1 hover:border-soft-gold transition-all">Add Address</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
