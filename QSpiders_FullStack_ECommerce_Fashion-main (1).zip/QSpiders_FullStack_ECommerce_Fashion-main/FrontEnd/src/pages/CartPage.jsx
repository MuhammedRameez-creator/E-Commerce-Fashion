import React, { useContext } from 'react';
import { CartContext } from '../context/CartContext';
import { Trash2 } from 'lucide-react';

const CartPage = () => {
  const { cartItems, removeFromCart } = useContext(CartContext);

  const subtotal = cartItems.reduce((acc, item) => acc + item.price * item.qty, 0);

  return (
    <div className="bg-cream min-h-screen px-6 py-24 md:px-10 lg:px-20">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col items-center mb-16">
          <h2 className="text-luxury text-5xl text-espresso mb-4">Shopping Bag</h2>
          <p className="text-[10px] tracking-[0.4em] uppercase text-muted-gold font-black">{cartItems.length} curated {cartItems.length === 1 ? 'item' : 'items'}</p>
        </div>
        
        {cartItems.length === 0 ? (
          <div className="glass p-20 rounded-[3rem] text-center max-w-2xl mx-auto">
            <div className="bg-espresso/5 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-8">
              <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-muted-gold"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
            </div>
            <h3 className="text-2xl font-serif text-espresso mb-4">Your bag is currently empty</h3>
            <p className="text-gray-500 text-sm mb-10 max-w-sm mx-auto">It seems you haven't added any of our exquisite pieces to your selection yet.</p>
            <Link to="/shop" className="bg-espresso text-cream text-[10px] uppercase tracking-[0.2em] font-bold py-5 px-14 rounded-full hover:bg-muted-gold transition-all duration-500 shadow-xl inline-block">
              Explore Collection
            </Link>
          </div>
        ) : (
          <div className="flex flex-col lg:flex-row gap-16 items-start">
            <div className="flex-1 w-full">
              <div className="space-y-8">
                {cartItems.map((item) => (
                  <div key={item._id} className="glass p-6 md:p-8 rounded-[2.5rem] flex flex-col md:flex-row items-center gap-8 group hover:shadow-[0_20px_50px_rgba(0,0,0,0.05)] transition-all duration-500">
                    <div className="w-24 h-32 flex-shrink-0 overflow-hidden rounded-2xl">
                      <img src={item.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={item.name} />
                    </div>
                    
                    <div className="flex-1 text-center md:text-left">
                      <span className="text-[9px] tracking-[0.3em] uppercase text-muted-gold font-black mb-2 block">{item.brand}</span>
                      <h3 className="text-lg font-serif text-espresso mb-1">{item.name}</h3>
                      <p className="text-xs text-gray-400">Size: One Size | Color: Original</p>
                    </div>

                    <div className="flex items-center gap-6">
                      <div className="flex items-center bg-espresso/5 rounded-full px-4 py-2">
                        <span className="text-xs font-bold text-espresso px-4">{item.qty}</span>
                      </div>
                      <div className="text-right min-w-[80px]">
                        <p className="text-sm font-bold text-espresso">${item.price * item.qty}</p>
                      </div>
                      <button onClick={() => removeFromCart(item._id)} className="p-3 text-gray-300 hover:text-red-500 transition-colors">
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="w-full lg:w-[400px] sticky top-32">
              <div className="glass p-10 md:p-12 rounded-[3rem] border border-white/60">
                <h3 className="text-xs tracking-[0.3em] uppercase font-black text-espresso mb-10 pb-4 border-b border-espresso/5">Order Overview</h3>
                
                <div className="space-y-6 mb-12">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-500 font-medium tracking-wide">Subtotal</span>
                    <span className="text-espresso font-bold">${subtotal}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-500 font-medium tracking-wide">Delivery</span>
                    <span className="text-muted-gold font-black tracking-widest text-[10px] uppercase">Complimentary</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-500 font-medium tracking-wide">VAT (Included)</span>
                    <span className="text-espresso font-bold">${(subtotal * 0.1).toFixed(0)}</span>
                  </div>
                  <div className="pt-6 border-t border-espresso/5 flex justify-between items-end">
                    <span className="text-xl font-serif text-espresso">Total</span>
                    <span className="text-2xl font-serif text-espresso">${subtotal}</span>
                  </div>
                </div>

                <button className="w-full bg-espresso text-cream py-5 text-[10px] tracking-[0.3em] uppercase font-black rounded-full hover:bg-muted-gold transition-all duration-500 shadow-2xl">
                  Secure Checkout
                </button>
                
                <div className="mt-8 flex items-center justify-center gap-4 opacity-30">
                   <div className="w-8 h-5 bg-espresso rounded-sm"></div>
                   <div className="w-8 h-5 bg-espresso rounded-sm"></div>
                   <div className="w-8 h-5 bg-espresso rounded-sm"></div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CartPage;
