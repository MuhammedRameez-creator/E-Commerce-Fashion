import React from 'react';

const ContactPage = () => {
  return (
    <div className="flex flex-col bg-[#FAFAFA] min-h-screen">
      <section className="h-[40vh] bg-[url('/img/banner/b16.jpg')] bg-cover bg-center flex flex-col items-center justify-center text-white text-center px-4 relative before:absolute before:inset-0 before:bg-deep-black/60">
        <div className="relative z-10 animate-slide-up">
          <h2 className="text-6xl font-serif mb-4">Contact Us</h2>
          <p className="text-sm tracking-widest uppercase font-medium text-soft-gold">We'd Love to Hear From You</p>
        </div>
      </section>

      <section className="py-24 px-10 max-w-6xl mx-auto w-full grid grid-cols-1 md:grid-cols-2 gap-20">
        <div>
          <h3 className="text-3xl font-serif text-deep-black mb-6">Get in Touch</h3>
          <p className="text-gray-500 mb-10 leading-relaxed">
            Visit one of our agency locations or contact us today. Our team is here to assist you with any inquiries.
          </p>
          <ul className="space-y-6">
            <li className="flex items-center gap-4 text-gray-600">
              <span className="font-bold text-deep-black uppercase text-xs tracking-widest w-20">Address</span>
              <span className="text-sm">56 Glassford Street, Glasgow G1 1UL, New York</span>
            </li>
            <li className="flex items-center gap-4 text-gray-600">
              <span className="font-bold text-deep-black uppercase text-xs tracking-widest w-20">Email</span>
              <span className="text-sm">contact@bagofclothes.com</span>
            </li>
            <li className="flex items-center gap-4 text-gray-600">
              <span className="font-bold text-deep-black uppercase text-xs tracking-widest w-20">Phone</span>
              <span className="text-sm">+01 2222 365 / (+91) 01 2345 6789</span>
            </li>
          </ul>
        </div>

        <div className="glass p-10 rounded-[2rem]">
          <form className="flex flex-col gap-6">
            <input type="text" placeholder="Your Name" className="bg-white/50 border-b border-gray-200 py-3 px-4 focus:outline-none focus:border-soft-gold transition-colors" />
            <input type="email" placeholder="Email Address" className="bg-white/50 border-b border-gray-200 py-3 px-4 focus:outline-none focus:border-soft-gold transition-colors" />
            <input type="text" placeholder="Subject" className="bg-white/50 border-b border-gray-200 py-3 px-4 focus:outline-none focus:border-soft-gold transition-colors" />
            <textarea placeholder="Your Message" rows="4" className="bg-white/50 border-b border-gray-200 py-3 px-4 focus:outline-none focus:border-soft-gold transition-colors resize-none"></textarea>
            <button className="bg-deep-black text-white text-[10px] tracking-[0.2em] uppercase font-bold py-4 rounded-full hover:bg-soft-gold transition-all duration-300 mt-4 shadow-xl">Send Message</button>
          </form>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;
