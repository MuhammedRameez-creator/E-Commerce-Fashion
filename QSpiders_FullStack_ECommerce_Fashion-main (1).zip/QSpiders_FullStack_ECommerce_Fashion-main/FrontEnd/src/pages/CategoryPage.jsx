import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import ProductCard from '../components/ProductCard';

const CategoryPage = ({ type }) => {
  const [products, setProducts] = useState([]);
  const { category } = useParams();
  
  const displayTitle = type || category || "Collection";

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const { data } = await axios.get('/api/products');
        let filtered = data;
        
        if (type === "Men's Collection") {
          // Mock filtering logic for demo
          filtered = data.filter(p => p.category === 'Shirts' || p.category === 'Jackets' || p.category === 'T-Shirts');
        } else if (type === "Women's Collection") {
          filtered = data.filter(p => p.category === 'Tops' || p.category === 'Trousers' || p.category === 'Dresses');
        } else if (type === "New Arrivals") {
          filtered = data.slice(-4);
        } else if (type === "Best Sellers") {
          filtered = data.slice(0, 4);
        } else if (displayTitle === "Dresses" || category === "dresses") {
          filtered = data.filter(p => p.category === 'Dresses');
        } else if (category) {
          filtered = data.filter(p => p.category.toLowerCase() === category.toLowerCase());
        }
        
        setProducts(filtered);
      } catch (error) {
        console.error('Error fetching products:', error);
      }
    };
    fetchProducts();
  }, [type, category]);

  return (
    <div className="flex flex-col bg-[#FAFAFA] min-h-screen pt-32 pb-20">
      <section className="px-10">
        <div className="flex flex-col mb-16 max-w-[1400px] mx-auto border-b border-gray-200 pb-8">
          <h4 className="text-soft-gold text-[10px] uppercase tracking-[0.4em] font-black mb-4">Explore</h4>
          <h2 className="text-5xl font-serif text-deep-black capitalize">{displayTitle}</h2>
          <p className="text-gray-500 text-sm mt-4 tracking-wide">{products.length} exquisite pieces found.</p>
        </div>
        
        <div className="flex flex-wrap justify-center gap-x-8 gap-y-16 max-w-[1500px] mx-auto">
          {products.length > 0 ? (
            products.map(product => (
              <ProductCard key={product._id} product={product} />
            ))
          ) : (
            <div className="text-center py-20 w-full">
              <p className="text-gray-400 tracking-widest text-sm uppercase">Coming Soon to our {displayTitle}</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default CategoryPage;
