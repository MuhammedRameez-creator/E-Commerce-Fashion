import React, { useState, useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import { useNavigate, Link } from 'react-router-dom';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await login(email, password);
      navigate('/');
    } catch (error) {
      alert('Login failed. Please check your credentials.');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[75vh] bg-[#FAFAFA] px-4">
      <div className="w-full max-w-sm">
        <h2 className="text-4xl font-serif text-deep-black text-center mb-2">Welcome Back</h2>
        <p className="text-xs tracking-widest uppercase text-gray-400 text-center mb-12">Sign in to your account</p>
        <form onSubmit={handleSubmit} className="flex flex-col gap-6">
          <input 
            type="email" 
            placeholder="Email Address" 
            className="border-b border-gray-200 bg-transparent py-4 text-sm text-deep-black placeholder-gray-400 focus:border-deep-black focus:outline-none transition-colors" 
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input 
            type="password" 
            placeholder="Password" 
            className="border-b border-gray-200 bg-transparent py-4 text-sm text-deep-black placeholder-gray-400 focus:border-deep-black focus:outline-none transition-colors" 
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button type="submit" className="bg-deep-black text-white py-4 text-xs tracking-widest uppercase font-semibold hover:bg-soft-gold transition-colors duration-300 mt-4 shadow-lg">
            Sign In
          </button>
        </form>
        <div className="mt-8 text-center">
          <p className="text-gray-500 text-xs tracking-wide">
            New to BAG of CLOTHES?{' '}
            <Link to="/register" className="text-deep-black font-bold hover:text-soft-gold transition-colors">
              Create Account
            </Link>
          </p>
        </div>
        <p className="mt-6 text-gray-400 text-[10px] tracking-widest uppercase text-center opacity-50">
          Demo: user@example.com / 123456
        </p>
      </div>
    </div>
  );
};

export default LoginPage;

