import React from 'react';

const SustainabilityPage = () => {
  return (
    <div className="flex flex-col bg-[#FAFAFA] min-h-screen">
      <section className="h-[60vh] bg-[url('/img/banner/b18.jpg')] bg-cover bg-center flex flex-col items-center justify-center text-white text-center px-4 relative before:absolute before:inset-0 before:bg-black/60">
        <div className="relative z-10 animate-slide-up max-w-3xl">
          <h2 className="text-7xl font-serif mb-6">Our Commitment</h2>
          <p className="text-sm tracking-[0.4em] uppercase font-bold text-soft-gold">Sustainability • Ethics • Future</p>
        </div>
      </section>

      <section className="py-24 px-10 max-w-4xl mx-auto">
        <div className="space-y-16">
          <div>
            <h3 className="text-3xl font-serif text-deep-black mb-6">Conscious Craftsmanship</h3>
            <p className="text-gray-600 leading-loose text-lg">
              At BAG of CLOTHES, we believe that luxury shouldn't come at the cost of the planet. 
              Our commitment to sustainability is woven into every thread of our business, 
              from the sourcing of organic materials to the ethical treatment of every artisan in our supply chain.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="glass p-10 rounded-[2.5rem]">
              <h4 className="text-xl font-serif mb-4 text-soft-gold">01. Materials</h4>
              <p className="text-sm text-gray-500 leading-relaxed">
                We prioritize GOTS-certified organic cotton, recycled polyester, and ethically sourced wool to reduce our environmental footprint.
              </p>
            </div>
            <div className="class p-10 rounded-[2.5rem] bg-deep-black text-white">
              <h4 className="text-xl font-serif mb-4 text-soft-gold">02. Ethics</h4>
              <p className="text-sm text-gray-400 leading-relaxed">
                100% of our production facilities are audited for fair wages, safe working conditions, and zero tolerance for forced labor.
              </p>
            </div>
          </div>

          <div>
            <h3 className="text-3xl font-serif text-deep-black mb-6">Circular Future</h3>
            <p className="text-gray-600 leading-loose text-lg">
              We are working towards a fully circular model by 2030, implementing take-back programs 
              and ensuring our packaging is 100% biodegradable or recyclable.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default SustainabilityPage;
