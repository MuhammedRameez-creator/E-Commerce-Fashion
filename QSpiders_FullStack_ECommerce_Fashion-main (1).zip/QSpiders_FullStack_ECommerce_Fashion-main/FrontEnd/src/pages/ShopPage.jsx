import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ProductCard from '../components/ProductCard';

const ShopPage = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const { data } = await axios.get('/api/products');
        setProducts(data);
      } catch (error) {
        console.error('Error fetching products:', error);
      }
    };
    fetchProducts();
  }, []);

  return (
    <div className="flex flex-col bg-[#FAFAFA] min-h-screen">
      <section className="h-[45vh] bg-[url('/img/banner/b1.jpg')] bg-cover bg-center bg-fixed flex flex-col items-center justify-center text-white text-center px-4 relative before:absolute before:inset-0 before:bg-deep-black/50">
        <div className="relative z-10 animate-slide-up">
          <h2 className="text-7xl font-serif mb-4">Signature Collection</h2>
          <p className="text-sm tracking-[0.4em] uppercase font-bold text-soft-gold">Exquisite Craftsmanship • Timeless Design</p>
        </div>
      </section>

      <section className="py-20 px-10">
        <div className="flex flex-col sm:flex-row justify-between items-center mb-12 max-w-[1400px] mx-auto border-b border-gray-200 pb-4 gap-4">
          <h3 className="text-2xl font-serif text-deep-black">All Products</h3>
          <span className="text-xs tracking-widest uppercase text-gray-500">{products.length} Results</span>
        </div>
        
        <div className="flex flex-wrap justify-center gap-x-6 gap-y-12 max-w-[1400px] mx-auto">
          {products.length > 0 ? (
            products.map(product => (
              <ProductCard key={product._id} product={product} />
            ))
          ) : (
            <p className="text-gray-500 tracking-widest text-sm uppercase text-center w-full">Loading collection...</p>
          )}
        </div>
      </section>
    </div>
  );
};

export default ShopPage;
