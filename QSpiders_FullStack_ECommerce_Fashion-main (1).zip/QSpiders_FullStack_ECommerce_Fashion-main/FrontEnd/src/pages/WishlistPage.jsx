import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, Trash2 } from 'lucide-react';

const WishlistPage = () => {
  // Mock wishlist data for now
  const wishlistItems = []; 

  return (
    <div className="bg-[#FAFAFA] min-h-screen pt-24 pb-20 px-10">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-5xl font-serif text-deep-black mb-4">My Wishlist</h2>
        <p className="text-gray-500 text-xs tracking-[0.3em] uppercase mb-16">Your Curated Favorites</p>

        {wishlistItems.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
            {/* Items would map here */}
          </div>
        ) : (
          <div className="glass p-20 rounded-[3rem] text-center max-w-2xl mx-auto">
            <div className="bg-black/5 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-8">
              <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-gray-400"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
            </div>
            <h3 className="text-2xl font-serif text-deep-black mb-4">Your wishlist is empty</h3>
            <p className="text-gray-500 text-sm mb-10 max-w-sm mx-auto">Save your favorite items here to keep track of what you love.</p>
            <Link to="/shop" className="bg-deep-black text-white text-[10px] uppercase tracking-[0.2em] font-bold py-5 px-12 rounded-full hover:bg-soft-gold transition-all duration-300 shadow-xl inline-block">
              Start Shopping
            </Link>
          </div>
        )}
      </div>
    </div>
  );
};

export default WishlistPage;
