import React from 'react';

const TermsPage = () => {
  return (
    <div className="bg-[#FAFAFA] min-h-screen pt-32 pb-24 px-10">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-5xl font-serif text-deep-black mb-12">Terms of Service</h1>
        
        <div className="space-y-12 text-gray-600 leading-relaxed">
          <section>
            <h3 className="text-xl font-serif text-deep-black mb-4">1. Acceptance of Terms</h3>
            <p>
              By accessing and using the BAG of CLOTHES website, you agree to comply with and be bound by these Terms of Service. 
              If you do not agree to these terms, please do not use our services.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-serif text-deep-black mb-4">2. Use of the Site</h3>
            <p>
              You may use the Site only for lawful purposes and in accordance with these Terms. You agree not to use the Site 
              in any way that violates any applicable federal, state, local, or international law or regulation.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-serif text-deep-black mb-4">3. Intellectual Property</h3>
            <p>
              The Site and its entire contents, features, and functionality (including but not limited to all information, 
              software, text, displays, images, video, and audio, and the design, selection, and arrangement thereof) 
              are owned by BAG of CLOTHES and are protected by international copyright and trademark laws.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-serif text-deep-black mb-4">4. Limitation of Liability</h3>
            <p>
              In no event will BAG of CLOTHES, its affiliates, or their licensors, service providers, employees, agents, 
              officers, or directors be liable for damages of any kind arising out of or in connection with your use 
              of the Site.
            </p>
          </section>

          <div className="pt-12 border-t border-gray-200">
            <p className="text-xs text-gray-400 italic">Last updated: May 1, 2024</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TermsPage;
