import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import ProductCard from '../components/ProductCard';

const HomePage = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const { data } = await axios.get('/api/products');
        setProducts(data);
      } catch (error) {
        console.error('Error fetching products:', error);
      }
    };
    fetchProducts();
  }, []);

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="h-[90vh] bg-[url('/img/hero4.png')] bg-cover bg-[center_top_20%] px-10 md:px-20 lg:px-40 flex flex-col items-start justify-center relative before:absolute before:inset-0 before:bg-black/5">
        <div className="max-w-2xl animate-slide-up relative z-10">
          <h4 className="text-xs font-bold tracking-[0.4em] uppercase text-gray-400 pb-4">New Arrival</h4>
          <h2 className="text-luxury text-8xl text-deep-black mb-6 drop-shadow-sm">Elegance <br /> Reimagined</h2>
          <p className="text-gray-600 py-6 text-base tracking-wide leading-relaxed font-medium max-w-lg">Save more with coupons & up to 70% off! Elevate your wardrobe with our latest high-fashion collection designed for the modern individual.</p>
          <div className="mt-8">
            <button className="bg-deep-black text-white text-[10px] tracking-[0.2em] uppercase font-bold py-6 px-14 hover:bg-soft-gold transition-all duration-500 rounded-full shadow-[0_20px_50px_rgba(0,0,0,0.1)] hover:shadow-soft-gold/30">Shop Now</button>
          </div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="py-24 px-10 max-w-[1400px] mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div className="max-w-xl">
            <h2 className="text-4xl font-serif text-deep-black mb-4">Curated Collections</h2>
            <p className="text-gray-500 text-sm tracking-wide leading-relaxed">Discover our meticulously crafted seasonal edits designed for every occasion.</p>
          </div>
          <Link to="/shop" className="text-[10px] uppercase tracking-[0.3em] font-black border-b-2 border-soft-gold pb-1 hover:text-soft-gold transition-colors">View All Collection</Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            { name: "Timeless Basics", img: "/img/banner/b17.jpg", size: "lg:col-span-2", bg: "bg-pastel-sage/30" },
            { name: "Urban Edge", img: "/img/banner/b10.jpg", size: "", bg: "bg-pastel-rose/30" },
            { name: "Elegant Evening", img: "/img/banner/b18.jpg", size: "", bg: "bg-pastel-blue/30" },
          ].map((cat, i) => (
            <div key={i} className={`group relative overflow-hidden rounded-[2.5rem] aspect-[4/5] cursor-pointer ${cat.size} ${cat.bg} border border-white/50 shadow-sm`}>
              <img src={cat.img} alt={cat.name} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110 grayscale-[0.3] group-hover:grayscale-0 opacity-80 group-hover:opacity-100" />
              <div className="absolute inset-0 bg-gradient-to-t from-espresso/60 via-transparent to-transparent flex flex-col justify-end p-10 opacity-90 group-hover:opacity-100 transition-opacity">
                <h4 className="text-white text-2xl font-serif mb-4 translate-y-4 group-hover:translate-y-0 transition-transform duration-500">{cat.name}</h4>
                <span className="text-cream text-[10px] uppercase tracking-[0.3em] font-bold opacity-0 group-hover:opacity-100 transition-all duration-500 delay-100">Explore Selection</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="text-center py-32 bg-white">
        <h4 className="text-soft-gold text-[10px] uppercase tracking-[0.4em] font-black mb-4">Trending Now</h4>
        <h2 className="text-5xl font-serif text-deep-black mb-20">Essential Pieces</h2>
        <div className="flex flex-wrap justify-center gap-x-8 gap-y-16 px-10 max-w-[1500px] mx-auto">
          {products.length > 0 ? (
            products.slice(0, 8).map(product => (
              <ProductCard key={product._id} product={product} />
            ))
          ) : (
            <p className="text-gray-500 tracking-widest text-sm uppercase">Loading collection...</p>
          )}
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-24 px-10">
        <div className="glass max-w-7xl mx-auto rounded-[4rem] p-16 md:p-24 flex flex-col lg:flex-row items-center justify-between gap-12 bg-[url('/img/banner/b14.png')] bg-cover bg-fixed relative overflow-hidden before:absolute before:inset-0 before:bg-espresso/80">
          <div className="relative z-10 text-center lg:text-left max-w-xl">
            <h2 className="text-4xl md:text-5xl font-serif text-cream mb-6">Join the Inner Circle</h2>
            <p className="text-pastel-sage text-sm tracking-wide leading-relaxed">
              Sign up for exclusive early access to new collections, secret sales, and 15% off your first order.
            </p>
          </div>
          <div className="relative z-10 w-full lg:w-auto">
            <form className="flex flex-col sm:flex-row gap-4" onSubmit={(e) => e.preventDefault()}>
              <input 
                type="email" 
                placeholder="Enter your email address" 
                className="glass-dark border-white/20 bg-white/5 text-cream placeholder:text-gray-400 py-4 px-8 rounded-full focus:outline-none focus:border-muted-gold/50 transition-all min-w-[320px] text-sm"
              />
              <button className="bg-cream text-espresso text-[10px] uppercase tracking-[0.2em] font-black py-4 px-10 rounded-full hover:bg-muted-gold hover:text-white transition-all duration-500 shadow-2xl">
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
