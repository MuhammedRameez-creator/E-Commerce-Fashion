import React, { useState, useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import { useNavigate, Link } from 'react-router-dom';

const RegisterPage = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { register } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await register(name, email, password);
      navigate('/');
    } catch (error) {
      alert('Registration failed. Email might already be taken.');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[75vh] bg-[#FAFAFA] px-4">
      <div className="w-full max-w-sm">
        <h2 className="text-4xl font-serif text-deep-black text-center mb-2">Create Account</h2>
        <p className="text-xs tracking-widest uppercase text-gray-400 text-center mb-12">Join BAG of CLOTHES today</p>
        <form onSubmit={handleSubmit} className="flex flex-col gap-6">
          <input 
            type="text" 
            placeholder="Full Name" 
            className="border-b border-gray-200 bg-transparent py-4 text-sm text-deep-black placeholder-gray-400 focus:border-deep-black focus:outline-none transition-colors" 
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
          <input 
            type="email" 
            placeholder="Email Address" 
            className="border-b border-gray-200 bg-transparent py-4 text-sm text-deep-black placeholder-gray-400 focus:border-deep-black focus:outline-none transition-colors" 
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input 
            type="password" 
            placeholder="Password" 
            className="border-b border-gray-200 bg-transparent py-4 text-sm text-deep-black placeholder-gray-400 focus:border-deep-black focus:outline-none transition-colors" 
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button type="submit" className="bg-deep-black text-white py-4 text-xs tracking-widest uppercase font-semibold hover:bg-soft-gold transition-colors duration-300 mt-4 shadow-lg">
            Create Account
          </button>
        </form>
        <div className="mt-8 text-center">
          <p className="text-gray-500 text-xs tracking-wide">
            Already have an account?{' '}
            <Link to="/login" className="text-deep-black font-bold hover:text-soft-gold transition-colors">
              Sign In
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;
