import React from 'react';

const AboutPage = () => {
  return (
    <div className="flex flex-col bg-[#FAFAFA] min-h-screen">
      <section className="h-[50vh] bg-[url('/img/about/banner.png')] bg-cover bg-center flex flex-col items-center justify-center text-white text-center px-4 relative before:absolute before:inset-0 before:bg-deep-black/60">
        <div className="relative z-10 animate-slide-up">
          <h2 className="text-6xl font-serif mb-4">Our Story</h2>
          <p className="text-sm tracking-widest uppercase font-medium text-soft-gold">Crafting Elegance Since 2024</p>
        </div>
      </section>

      <section className="py-24 px-10 max-w-5xl mx-auto text-center">
        <h3 className="text-3xl font-serif text-deep-black mb-8">Who We Are</h3>
        <p className="text-gray-600 leading-loose text-lg mb-12">
          At BAG of CLOTHES, we believe that fashion is more than just what you wear—it's an expression of your identity. 
          Founded with a passion for timeless design and premium quality, we curate collections that blend modern trends 
          with classic sophistication.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mt-16">
          <div className="p-8 glass rounded-[2rem]">
            <h4 className="font-serif text-xl mb-4">Quality</h4>
            <p className="text-sm text-gray-500">We source only the finest fabrics and materials for our garments.</p>
          </div>
          <div className="p-8 glass rounded-[2rem]">
            <h4 className="font-serif text-xl mb-4">Design</h4>
            <p className="text-sm text-gray-500">Every piece is designed with meticulous attention to detail.</p>
          </div>
          <div className="p-8 glass rounded-[2rem]">
            <h4 className="font-serif text-xl mb-4">Sustainability</h4>
            <p className="text-sm text-gray-500">Committed to ethical sourcing and sustainable fashion practices.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;
