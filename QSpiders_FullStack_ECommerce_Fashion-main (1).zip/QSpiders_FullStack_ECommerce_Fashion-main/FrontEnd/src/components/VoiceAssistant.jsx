import React, { useState, useEffect } from 'react';
import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';
import { Mic, MicOff, Volume2 } from 'lucide-react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const VoiceAssistant = () => {
  const [isListening, setIsListening] = useState(false);
  const [response, setResponse] = useState('');
  const navigate = useNavigate();
  const { transcript, resetTranscript, browserSupportsSpeechRecognition } = useSpeechRecognition();

  useEffect(() => {
    if (!isListening && transcript) {
      handleVoiceCommand(transcript);
    }
  }, [isListening, transcript]);

  const handleVoiceCommand = async (text) => {
    try {
      const { data } = await axios.post('/api/voice', { transcript: text });
      const ai = data.aiResponse;
      
      setResponse(ai.response);
      
      if (ai.command === 'NAVIGATE') {
        navigate(ai.path);
      }
      
      // Speak back
      const utterance = new SpeechSynthesisUtterance(ai.response);
      window.speechSynthesis.speak(utterance);
      
      resetTranscript();
    } catch (error) {
      console.error('Voice Error:', error);
    }
  };

  const toggleListening = () => {
    if (isListening) {
      SpeechRecognition.stopListening();
      setIsListening(false);
    } else {
      resetTranscript();
      SpeechRecognition.startListening({ continuous: true });
      setIsListening(true);
    }
  };

  if (!browserSupportsSpeechRecognition) return null;

  return (
    <div className="fixed bottom-8 left-8 z-[100]">
      {response && (
        <div className="glass p-6 mb-4 max-w-xs rounded-[2rem] border-muted-gold/20 animate-fade-in shadow-2xl">
          <p className="text-[10px] tracking-[0.2em] uppercase font-black text-muted-gold mb-2">Assistant</p>
          <p className="text-sm tracking-wide text-espresso leading-relaxed italic">"{response}"</p>
        </div>
      )}
      <button 
        onClick={toggleListening}
        className={`p-5 rounded-full shadow-[0_15px_40px_rgba(0,0,0,0.1)] transition-all duration-500 transform hover:scale-110 flex items-center justify-center ${isListening ? 'bg-red-500 text-cream animate-pulse' : 'bg-espresso text-cream hover:bg-muted-gold'}`}
      >
        {isListening ? <MicOff size={22} strokeWidth={2.5} /> : <Mic size={22} strokeWidth={2.5} />}
      </button>
    </div>
  );
};

export default VoiceAssistant;
