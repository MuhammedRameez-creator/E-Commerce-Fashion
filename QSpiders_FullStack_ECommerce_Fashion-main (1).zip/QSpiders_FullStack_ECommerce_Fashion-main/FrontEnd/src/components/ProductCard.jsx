import React, { useContext, useState } from 'react';
import { ShoppingCart, Star } from 'lucide-react';
import { CartContext } from '../context/CartContext';
import QuickViewModal from './QuickViewModal';

const ProductCard = ({ product }) => {
  const { addToCart } = useContext(CartContext);
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <div className="w-full sm:w-[320px] bg-white group cursor-pointer transition-all duration-500 animate-fade-in flex flex-col relative overflow-hidden rounded-[2.5rem] hover:shadow-[0_20px_50px_rgba(0,0,0,0.05)] border border-espresso/5">
        <div className="overflow-hidden bg-[#FAFAFA] relative aspect-[3/4]">
          <img src={product.image} alt={product.name} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110 grayscale-[0.2] group-hover:grayscale-0" />
          
          {/* Wishlist Button */}
          <button className="absolute top-6 right-6 p-3 bg-white/80 backdrop-blur-md rounded-full opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-white hover:text-red-500 z-20 shadow-sm">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-heart"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
          </button>

          <div className="absolute inset-x-0 bottom-0 p-6 translate-y-full opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500 ease-out z-10 flex flex-col gap-3">
            <button 
              onClick={(e) => { e.stopPropagation(); addToCart(product); }}
              className="w-full bg-espresso text-cream py-4 px-6 text-[10px] tracking-[0.2em] uppercase font-black hover:bg-muted-gold transition-all duration-500 flex items-center justify-center gap-3 rounded-full shadow-2xl"
            >
              <ShoppingCart size={14} strokeWidth={2.5} /> Add to Bag
            </button>
            <button 
              onClick={(e) => { e.stopPropagation(); setIsModalOpen(true); }}
              className="w-full glass text-espresso py-4 px-6 text-[10px] tracking-[0.2em] uppercase font-black hover:bg-white transition-all duration-500 rounded-full"
            >
              Quick View
            </button>
          </div>
        </div>
        
        <div className="pt-8 pb-6 px-4 text-center flex flex-col items-center">
          <span className="text-muted-gold text-[9px] tracking-[0.4em] uppercase font-black mb-3">{product.brand}</span>
          <h5 className="text-espresso font-serif text-lg mb-2 line-clamp-1">{product.name}</h5>
          <div className="flex items-center gap-3">
            <span className="font-bold text-espresso text-sm">${product.price}</span>
            <span className="text-gray-300 text-xs line-through tracking-tighter">${(product.price * 1.4).toFixed(0)}</span>
          </div>
        </div>
      </div>

      <QuickViewModal 
        product={product} 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onAddToCart={addToCart} 
      />
    </>
  );
};

export default ProductCard;
