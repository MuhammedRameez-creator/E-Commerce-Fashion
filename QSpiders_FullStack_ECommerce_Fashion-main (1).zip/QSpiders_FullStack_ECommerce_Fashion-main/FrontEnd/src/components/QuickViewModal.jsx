import React from 'react';
import { X, ShoppingBag, Heart, Star } from 'lucide-react';

const QuickViewModal = ({ product, isOpen, onClose, onAddToCart }) => {
  if (!isOpen || !product) return null;

  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 md:p-10 bg-espresso/60 backdrop-blur-md animate-fade-in">
      <div className="glass max-w-5xl w-full rounded-[3rem] overflow-hidden flex flex-col md:flex-row relative shadow-2xl animate-slide-up bg-cream">
        <button 
          onClick={onClose}
          className="absolute top-8 right-8 z-10 p-2 bg-espresso/5 hover:bg-espresso/10 rounded-full text-espresso transition-all"
        >
          <X size={24} />
        </button>

        {/* Product Image */}
        <div className="md:w-1/2 h-80 md:h-[600px] overflow-hidden bg-beige/30">
          <img src={product.image} alt={product.name} className="w-full h-full object-cover transition-transform duration-1000 hover:scale-110" />
        </div>

        {/* Product Details */}
        <div className="md:w-1/2 p-10 md:p-16 flex flex-col justify-center">
          <span className="text-muted-gold text-[10px] uppercase tracking-[0.4em] font-black mb-4">{product.brand}</span>
          <h2 className="text-4xl md:text-5xl font-serif text-espresso mb-4">{product.name}</h2>
          
          <div className="flex items-center gap-4 mb-8">
            <span className="text-2xl font-bold text-espresso">${product.price}</span>
            <span className="text-gray-300 line-through text-lg">${(product.price * 1.4).toFixed(0)}</span>
            <span className="bg-pastel-rose/50 text-espresso text-[10px] px-3 py-1 rounded-full font-bold uppercase tracking-wider">40% OFF</span>
          </div>

          <div className="flex items-center gap-1 mb-8">
            {[...Array(5)].map((_, i) => (
              <Star key={i} size={14} fill={i < 4 ? "#C5B358" : "none"} stroke="#C5B358" />
            ))}
            <span className="text-xs text-gray-400 ml-2">(128 reviews)</span>
          </div>

          <p className="text-gray-500 text-sm mb-12 leading-loose">
            {product.description || "Indulge in the epitome of luxury with our signature collection. Meticulously crafted from the finest materials, this piece embodies timeless elegance and contemporary sophistication."}
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <button 
              onClick={() => { onAddToCart(product); onClose(); }}
              className="flex-1 bg-espresso text-cream text-[10px] uppercase tracking-[0.3em] font-black py-5 rounded-full hover:bg-muted-gold transition-all duration-500 shadow-2xl flex items-center justify-center gap-3"
            >
              <ShoppingBag size={18} /> Add to Bag
            </button>
            <button className="p-5 border border-espresso/10 rounded-full hover:bg-espresso/5 transition-colors text-espresso">
              <Heart size={20} />
            </button>
          </div>

          <div className="mt-12 pt-8 border-t border-espresso/5 space-y-4">
            <p className="text-[10px] uppercase tracking-widest text-gray-400 flex items-center gap-3">
              <span className="w-2 h-2 rounded-full bg-green-400"></span> In Stock & Ready to Ship
            </p>
            <p className="text-[10px] uppercase tracking-widest text-gray-400">Category: <span className="text-espresso font-bold">{product.category}</span></p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuickViewModal;
