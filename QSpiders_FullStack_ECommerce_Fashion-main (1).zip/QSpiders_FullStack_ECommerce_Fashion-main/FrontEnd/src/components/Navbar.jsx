import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, User, LogOut, Menu, X } from 'lucide-react';
import { AuthContext } from '../context/AuthContext';
import { CartContext } from '../context/CartContext';

const Navbar = () => {
  const { user, logout } = useContext(AuthContext);
  const { cartItems } = useContext(CartContext);
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <nav className="glass sticky top-4 z-50 px-12 py-3 flex items-center justify-between w-[92%] max-w-7xl mx-auto rounded-full transition-all duration-700 hover:w-[94%] hover:shadow-[0_20px_80px_rgba(0,0,0,0.1)] group">
      <Link to="/" className="flex items-center gap-2 group/logo">
        <span className="font-serif text-xl tracking-tighter font-black text-deep-black group-hover/logo:text-soft-gold transition-all duration-500">
          BAG <span className="font-light italic text-xs tracking-normal opacity-50">of</span> CLOTHES
        </span>
      </Link>

      <ul className={`${isOpen ? 'flex' : 'hidden'} md:flex absolute md:relative top-[130%] left-0 w-full md:w-auto glass md:bg-transparent flex-col md:flex-row items-center gap-10 py-10 md:py-0 shadow-2xl md:shadow-none transition-all rounded-[2.5rem] md:rounded-none border-none`}>
        <li><Link to="/" className="text-deep-black text-[9px] uppercase tracking-[0.4em] font-black hover:text-soft-gold transition-all duration-300">Home</Link></li>
        <li><Link to="/shop" className="text-deep-black text-[9px] uppercase tracking-[0.4em] font-black hover:text-soft-gold transition-all duration-300">Shop</Link></li>
        <li><Link to="/about" className="text-deep-black text-[9px] uppercase tracking-[0.4em] font-black hover:text-soft-gold transition-all duration-300">About</Link></li>
        <li><Link to="/contact" className="text-deep-black text-[9px] uppercase tracking-[0.4em] font-black hover:text-soft-gold transition-all duration-300">Contact</Link></li>
      </ul>

      <div className="hidden lg:flex items-center bg-black/5 rounded-full px-4 py-1.5 border border-black/5 focus-within:border-soft-gold/30 transition-all">
        <input type="text" placeholder="Search collection..." className="bg-transparent border-none focus:outline-none text-[10px] uppercase tracking-widest w-32 focus:w-48 transition-all placeholder:text-gray-400 font-medium" />
      </div>

      <div className="flex items-center gap-6">
        <Link to="/wishlist" className="text-deep-black hover:text-soft-gold transition-colors relative">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-heart"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
        </Link>
        
        <Link to="/cart" className="text-deep-black hover:text-soft-gold transition-colors relative">
          <ShoppingBag size={18} strokeWidth={2} />
          {cartItems.length > 0 && (
            <span className="absolute -top-1.5 -right-2 bg-soft-gold text-white text-[8px] rounded-full w-4 h-4 flex items-center justify-center font-bold">
              {cartItems.length}
            </span>
          )}
        </Link>

        {user ? (
          <div className="flex items-center gap-4">
            <Link to="/profile" className="text-deep-black hover:text-soft-gold transition-colors">
              <User size={18} strokeWidth={2} />
            </Link>
            <button onClick={logout} className="text-deep-black hover:text-red-500 transition-colors"><LogOut size={18} strokeWidth={2} /></button>
          </div>
        ) : (
          <Link to="/login" className="text-deep-black hover:text-soft-gold transition-colors"><User size={18} strokeWidth={2} /></Link>
        )}
      </div>

      <button className="md:hidden text-deep-black p-2 hover:bg-black/5 rounded-full transition-colors" onClick={() => setIsOpen(!isOpen)}>
        {isOpen ? <X size={22} strokeWidth={2} /> : <Menu size={22} strokeWidth={2} />}
      </button>
    </nav>
  );
};

export default Navbar;
