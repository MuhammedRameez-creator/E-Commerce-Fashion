import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Twitter, Facebook, Youtube, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-white pt-24 pb-12 px-10 border-t border-gray-100">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-20">
        <div className="flex flex-col gap-6">
          <Link to="/" className="font-serif text-2xl font-black tracking-tighter">
            BAG <span className="font-light italic text-sm opacity-60">of</span> CLOTHES
          </Link>
          <p className="text-gray-500 text-sm leading-relaxed max-w-xs">
            Elevating everyday essentials into luxury statements. Sustainable, premium, and designed for the modern individual.
          </p>
          <div className="flex gap-5">
            <a href="#" className="text-gray-400 hover:text-soft-gold transition-colors"><Instagram size={18} /></a>
            <a href="#" className="text-gray-400 hover:text-soft-gold transition-colors"><Twitter size={18} /></a>
            <a href="#" className="text-gray-400 hover:text-soft-gold transition-colors"><Facebook size={18} /></a>
            <a href="#" className="text-gray-400 hover:text-soft-gold transition-colors"><Youtube size={18} /></a>
          </div>
        </div>

        <div>
          <h4 className="text-[10px] uppercase tracking-[0.3em] font-bold text-deep-black mb-8">Shop</h4>
          <ul className="flex flex-col gap-4">
            <li><Link to="/new-arrivals" className="text-gray-500 text-sm hover:text-soft-gold transition-colors">New Arrivals</Link></li>
            <li><Link to="/best-sellers" className="text-gray-500 text-sm hover:text-soft-gold transition-colors">Best Sellers</Link></li>
            <li><Link to="/mens-collection" className="text-gray-500 text-sm hover:text-soft-gold transition-colors">Men's Collection</Link></li>
            <li><Link to="/womens-collection" className="text-gray-500 text-sm hover:text-soft-gold transition-colors">Women's Collection</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-[10px] uppercase tracking-[0.3em] font-bold text-deep-black mb-8">Company</h4>
          <ul className="flex flex-col gap-4">
            <li><Link to="/about" className="text-gray-500 text-sm hover:text-soft-gold transition-colors">Our Story</Link></li>
            <li><Link to="/contact" className="text-gray-500 text-sm hover:text-soft-gold transition-colors">Contact Us</Link></li>
            <li><Link to="/sustainability" className="text-gray-500 text-sm hover:text-soft-gold transition-colors">Sustainability</Link></li>
            <li><Link to="/terms" className="text-gray-500 text-sm hover:text-soft-gold transition-colors">Terms of Service</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-[10px] uppercase tracking-[0.3em] font-bold text-deep-black mb-8">Support</h4>
          <ul className="flex flex-col gap-6">
            <li className="flex items-start gap-4 text-gray-500 text-sm">
              <MapPin size={18} className="text-soft-gold flex-shrink-0" />
              <span>56 Glassford Street, Glasgow G1 1UL, New York</span>
            </li>
            <li className="flex items-center gap-4 text-gray-500 text-sm">
              <Mail size={18} className="text-soft-gold flex-shrink-0" />
              <span>contact@bagofclothes.com</span>
            </li>
            <li className="flex items-center gap-4 text-gray-500 text-sm">
              <Phone size={18} className="text-soft-gold flex-shrink-0" />
              <span>+01 2222 365 / (+91) 01 2345</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto pt-12 border-t border-gray-100 flex flex-col md:flex-row justify-between items-center gap-6">
        <p className="text-gray-400 text-xs tracking-wide">© 2024 BAG of CLOTHES. All rights reserved.</p>
        <div className="flex gap-8">
          <p className="text-gray-400 text-xs tracking-wide hover:text-deep-black cursor-pointer transition-colors">Privacy Policy</p>
          <p className="text-gray-400 text-xs tracking-wide hover:text-deep-black cursor-pointer transition-colors">Terms & Conditions</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
