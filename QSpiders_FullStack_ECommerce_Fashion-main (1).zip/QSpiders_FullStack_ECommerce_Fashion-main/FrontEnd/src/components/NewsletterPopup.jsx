import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';

const NewsletterPopup = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      const hasSeenPopup = localStorage.getItem('hasSeenNewsletterPopup');
      if (!hasSeenPopup) {
        setIsVisible(true);
      }
    }, 5000); // Show after 5 seconds

    return () => clearTimeout(timer);
  }, []);

  const closePopup = () => {
    setIsVisible(false);
    localStorage.setItem('hasSeenNewsletterPopup', 'true');
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-black/40 backdrop-blur-sm animate-fade-in">
      <div className="glass max-w-4xl w-full rounded-[3rem] overflow-hidden flex flex-col md:flex-row relative shadow-2xl animate-slide-up">
        <button 
          onClick={closePopup}
          className="absolute top-6 right-6 z-10 p-2 bg-white/20 hover:bg-white/40 rounded-full text-white transition-all"
        >
          <X size={20} />
        </button>

        <div className="md:w-1/2 h-64 md:h-auto overflow-hidden">
          <img src="/img/banner/b16.jpg" alt="Newsletter" className="w-full h-full object-cover" />
        </div>

        <div className="md:w-1/2 p-12 md:p-16 flex flex-col justify-center bg-white">
          <h4 className="text-soft-gold text-[10px] uppercase tracking-[0.4em] font-black mb-4">Exclusive Access</h4>
          <h2 className="text-4xl font-serif text-deep-black mb-6">Enjoy 15% Off Your First Order</h2>
          <p className="text-gray-500 text-sm mb-10 leading-relaxed">
            Join our elite community and be the first to receive updates on new collections, private sales, and sartorial inspiration.
          </p>
          
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); closePopup(); }}>
            <input 
              type="email" 
              placeholder="Your email address" 
              className="w-full border-b border-gray-200 py-4 px-2 focus:outline-none focus:border-soft-gold transition-colors text-sm"
              required
            />
            <button className="w-full bg-deep-black text-white text-[10px] uppercase tracking-[0.2em] font-bold py-5 rounded-full hover:bg-soft-gold transition-all duration-500 shadow-xl mt-4">
              Join the List
            </button>
          </form>
          
          <p className="text-[9px] text-gray-400 mt-8 uppercase tracking-widest text-center">
            *By signing up, you agree to our Terms & Privacy Policy.
          </p>
        </div>
      </div>
    </div>
  );
};

export default NewsletterPopup;
