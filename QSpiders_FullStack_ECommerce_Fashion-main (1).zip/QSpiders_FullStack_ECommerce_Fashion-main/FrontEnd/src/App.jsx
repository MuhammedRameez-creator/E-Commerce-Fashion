import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { CartProvider } from './context/CartContext';
import Navbar from './components/Navbar';
import VoiceAssistant from './components/VoiceAssistant';
import HomePage from './pages/HomePage';
import CartPage from './pages/CartPage';
import ShopPage from './pages/ShopPage';
import LoginPage from './pages/LoginPage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import RegisterPage from './pages/RegisterPage';
import WishlistPage from './pages/WishlistPage';
import ProfilePage from './pages/ProfilePage';
import CategoryPage from './pages/CategoryPage';
import SustainabilityPage from './pages/SustainabilityPage';
import TermsPage from './pages/TermsPage';
import Footer from './components/Footer';
import NewsletterPopup from './components/NewsletterPopup';
import ScrollToTop from './components/ScrollToTop';
import CustomCursor from './components/CustomCursor';

function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <Router>
          <CustomCursor />
          <Navbar />
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/cart" element={<CartPage />} />
            <Route path="/shop" element={<ShopPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/wishlist" element={<WishlistPage />} />
            <Route path="/profile" element={<ProfilePage />} />
            
            {/* Collections */}
            <Route path="/new-arrivals" element={<CategoryPage type="New Arrivals" />} />
            <Route path="/best-sellers" element={<CategoryPage type="Best Sellers" />} />
            <Route path="/mens-collection" element={<CategoryPage type="Men's Collection" />} />
            <Route path="/womens-collection" element={<CategoryPage type="Women's Collection" />} />
            
            {/* Static Content */}
            <Route path="/sustainability" element={<SustainabilityPage />} />
            <Route path="/terms" element={<TermsPage />} />
          </Routes>
          <Footer />
          <NewsletterPopup />
          <ScrollToTop />
          <VoiceAssistant />
        </Router>
      </CartProvider>
    </AuthProvider>
  );
}

export default App;
