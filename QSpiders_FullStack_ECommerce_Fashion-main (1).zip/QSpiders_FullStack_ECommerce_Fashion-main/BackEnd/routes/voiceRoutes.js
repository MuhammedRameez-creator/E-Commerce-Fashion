import express from 'express';

const router = express.Router();

router.post('/', async (req, res) => {
  const { transcript } = req.body;
  const text = transcript.toLowerCase();

  let aiResponse = {
    response: "I didn't quite catch that. Can you try saying 'go to cart' or 'show shop'?",
    command: null,
    path: null
  };

  if (text.includes('cart') || text.includes('basket')) {
    aiResponse = {
      response: "Sure, opening your shopping cart.",
      command: 'NAVIGATE',
      path: '/cart'
    };
  } else if (text.includes('shop') || text.includes('store')) {
    aiResponse = {
      response: "Heading to the shop page now.",
      command: 'NAVIGATE',
      path: '/shop'
    };
  } else if (text.includes('home')) {
    aiResponse = {
      response: "Taking you back home.",
      command: 'NAVIGATE',
      path: '/'
    };
  } else if (text.includes('login') || text.includes('account')) {
    aiResponse = {
      response: "Opening the login page.",
      command: 'NAVIGATE',
      path: '/login'
    };
  } else if (text.includes('hello') || text.includes('hi')) {
    aiResponse = {
      response: "Hello! How can I help you navigate the Bag of Clothes store today?",
      command: null,
      path: null
    };
  }

  res.json({ aiResponse });
});

export default router;
