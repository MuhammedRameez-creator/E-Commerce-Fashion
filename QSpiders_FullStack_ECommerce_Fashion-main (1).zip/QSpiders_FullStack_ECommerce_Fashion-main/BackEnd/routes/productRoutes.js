import express from 'express';
import Product from '../models/Product.js';

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    let products = await Product.find({});
    
    // Seed sample products if empty
    // Seed sample products if empty or low count
    if (products.length < 20) {
      const sampleProducts = [
        { name: 'Cartoon Astronaut T-Shirts', brand: 'adidas', price: 78, category: 'T-Shirts', countInStock: 10, image: '/img/products/f1.jpg', description: 'Pure cotton comfortable t-shirt' },
        { name: 'Floral Print Shirt', brand: 'nike', price: 85, category: 'Shirts', countInStock: 5, image: '/img/products/f2.jpg', description: 'Modern floral design' },
        { name: 'Classic White Shirt', brand: 'zara', price: 92, category: 'Shirts', countInStock: 8, image: '/img/products/f3.jpg', description: 'Elegance redefined' },
        { name: 'Urban Streetwear Jacket', brand: 'hm', price: 120, category: 'Jackets', countInStock: 3, image: '/img/products/f4.jpg', description: 'Cool urban style' },
        { name: 'Casual Denim Shirt', brand: 'levis', price: 65, category: 'Shirts', countInStock: 12, image: '/img/products/f5.jpg', description: 'Rugged and durable' },
        { name: 'Summer Breeze Top', brand: 'forever21', price: 45, category: 'Tops', countInStock: 15, image: '/img/products/f6.jpg', description: 'Lightweight summer top' },
        { name: 'Linen Blend Trousers', brand: 'zara', price: 110, category: 'Trousers', countInStock: 7, image: '/img/products/n1.jpg', description: 'Breathable linen comfort' },
        { name: 'Minimalist Oxford Shirt', brand: 'ralph lauren', price: 145, category: 'Shirts', countInStock: 4, image: '/img/products/n2.jpg', description: 'Timeless oxford weave' },
        { name: 'Slim Fit Chinos', brand: 'gap', price: 89, category: 'Trousers', countInStock: 9, image: '/img/products/n3.jpg', description: 'Perfect for every day' },
        { name: 'Tech Shell Parka', brand: 'north face', price: 295, category: 'Jackets', countInStock: 2, image: '/img/products/n4.jpg', description: 'Weather resistant techwear' },
        { name: 'Premium Knit Sweater', brand: 'uniqlo', price: 75, category: 'Knitwear', countInStock: 11, image: '/img/products/n5.jpg', description: 'Soft merino wool blend' },
        { name: 'Corduroy Overshirt', brand: 'carhartt', price: 130, category: 'Shirts', countInStock: 6, image: '/img/products/n6.jpg', description: 'Vintage inspired corduroy' },
        { name: 'Graphic Art Tee', brand: 'off-white', price: 180, category: 'T-Shirts', countInStock: 5, image: '/img/products/n7.jpg', description: 'Limited edition graphic' },
        { name: 'Tailored Wool Blazer', brand: 'armani', price: 450, category: 'Jackets', countInStock: 2, image: '/img/products/n8.jpg', description: 'Luxury tailored fit' },
        { name: 'Silk Evening Gown', brand: 'gucci', price: 2450, category: 'Dresses', countInStock: 2, image: '/img/products/f7.jpg', description: 'Pure silk floor-length gown' },
        { name: 'Bohemian Summer Dress', brand: 'zara', price: 89, category: 'Dresses', countInStock: 12, image: '/img/products/f8.jpg', description: 'Flowy floral summer dress' },
        { name: 'Little Black Dress', brand: 'chanel', price: 1200, category: 'Dresses', countInStock: 4, image: '/img/products/n1.jpg', description: 'The timeless classic' },
        { name: 'Satin Wrap Dress', brand: 'asos', price: 75, category: 'Dresses', countInStock: 15, image: '/img/products/n2.jpg', description: 'Elegant satin wrap design' },
        { name: 'Velvet Party Dress', brand: 'hm', price: 95, category: 'Dresses', countInStock: 8, image: '/img/products/n3.jpg', description: 'Luxurious velvet finish' },
        { name: 'Pleated Maxi Dress', brand: 'mango', price: 110, category: 'Dresses', countInStock: 6, image: '/img/products/n4.jpg', description: 'Beautiful pleated details' },
      ];
      // Only insert products that don't already exist by name
      for (const p of sampleProducts) {
        const exists = await Product.findOne({ name: p.name });
        if (!exists) {
          await Product.create(p);
        }
      }
      products = await Product.find({});
    }
    
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
});

router.get('/:id', async (req, res) => {
  const product = await Product.findById(req.params.id);
  if (product) {
    res.json(product);
  } else {
    res.status(404).json({ message: 'Product not found' });
  }
});

export default router;
