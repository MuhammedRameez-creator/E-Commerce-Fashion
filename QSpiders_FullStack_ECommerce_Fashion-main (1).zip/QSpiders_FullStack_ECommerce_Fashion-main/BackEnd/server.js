import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import authRoutes from './routes/authRoutes.js';
import productRoutes from './routes/productRoutes.js';
import voiceRoutes from './routes/voiceRoutes.js';

dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());

// Routes
const router = express.Router();
router.use('/auth', authRoutes);
router.use('/products', productRoutes);
router.use('/voice', voiceRoutes);

router.get('/', (req, res) => {
  res.send('Bag of Clothes API is running...');
});

// Setup paths for both local and Netlify environments
app.use('/api', router);
app.use('/.netlify/functions/api', router);

mongoose.connect(process.env.MONGODB_URI)
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch((err) => {
    console.error('MongoDB connection error:', err.message);
    console.log('Server will continue to run, but database features will be unavailable.');
  });

export default app;
