# BAG of CLOTHES 🧥✨

### Luxury Fashion E-Commerce Experience

BAG of CLOTHES is a premium, full-stack e-commerce application designed for the modern fashion house. Built with a focus on minimalist luxury and high-fashion editorial design, it features a sophisticated glassmorphism design system, AI-driven voice navigation, and a curated shopping experience.

---

## 🌟 Key Features

- **💎 Luxury Glassmorphism UI**: A stunning, modern interface featuring a cream and pastel color palette, smooth animations, and a magazine-style editorial layout.
- **🎙️ AI Voice Assistant**: Navigate the entire store, search for products, and get style advice using integrated voice commands.
- **🔍 Quick View Modal**: Inspect products instantly with a detailed, high-end popup featuring descriptions, reviews, and quick "Add to Bag" actions.
- **🧭 Dynamic Collections**: Curated views for "New Arrivals", "Best Sellers", and Gender-specific collections (Men/Women).
- **🛍️ Feature-Rich Shopping Bag**: A polished checkout flow with complimentary shipping indicators and quantity management.
- **✨ Micro-interactions**: Custom luxury cursor, smooth page transitions, and hover-triggered expansion effects across the site.
- **📧 Exclusive Access**: Intelligent newsletter popup for driving customer engagement and conversions.

---

## 🛠️ Technology Stack

### Frontend
- **React.js**: Core library for building the user interface.
- **Tailwind CSS**: Used for the premium design system and utility-first styling.
- **Lucide React**: High-quality iconography.
- **React Speech Recognition**: Powers the AI Voice Assistant.
- **Axios**: Handling API requests to the backend.

### Backend
- **Node.js & Express**: Scalable backend architecture.
- **MongoDB & Mongoose**: Flexible, high-performance database.
- **JWT**: Secure authentication system.
- **Dotenv**: Environment variable management.

---

## 🚀 Getting Started

### Prerequisites
- Node.js (v16+)
- MongoDB Atlas account or local MongoDB instance

### Installation

1. **Clone the repository:**
   ```bash
   git clone https://github.com/Rizviriyaz/bag-of-clothes.git
   cd bag-of-clothes
   ```

2. **Setup Backend:**
   ```bash
   cd BackEnd
   npm install
   ```
   Create a `.env` file in the `BackEnd` directory and add your credentials:
   ```env
   MONGODB_URI=your_mongodb_connection_string
   JWT_SECRET=your_jwt_secret
   PORT=5000
   ```

3. **Setup Frontend:**
   ```bash
   cd ../FrontEnd
   npm install
   ```

### Running the Application

1. **Start Backend Server:**
   ```bash
   cd BackEnd
   npm run dev
   ```

2. **Start Frontend Dev Server:**
   ```bash
   cd FrontEnd
   npm run dev
   ```

3. **Open the browser:**
   Navigate to `http://localhost:5173/`

---

## 🌿 Sustainability

We believe in conscious craftsmanship. This project reflects our commitment to sustainable web practices, minimizing code bloat and prioritizing performance to reduce our digital footprint.

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

Designed with ❤️ for the future of fashion.
